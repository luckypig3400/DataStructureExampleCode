# !/bin/sh
# -----------------------------------------------------------------------------
# Start Script for the Everyone's Java Editor (EJE) 1.0
# -----------------------------------------------------------------------------

java -splash:resources/images/splash.png -classpath . com.cdsc.eje.gui.EJE
